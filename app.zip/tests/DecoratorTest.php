<?php
use PHPUnit\Framework\TestCase;

class DecoratorTest extends TestCase
{
    public function testBonusMultiplierApplies()
    {
        $strategy = new Fidelidade\Strategies\TierAccumulationStrategy('bronze');
        $program = new Fidelidade\Domain\LoyaltyProgram($strategy);

        $program->addDecorator(new Fidelidade\Decorators\BonusMultiplierDecorator(50));
        $pts = $program->purchase(100);
        $this->assertEquals(150, $pts);
    }
}

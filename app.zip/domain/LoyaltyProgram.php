<?php
namespace Fidelidade\Domain;

use Fidelidade\Observers\Subject;
use Fidelidade\Strategies\AccumulationStrategyInterface;
use Fidelidade\Decorators\PointsDecoratorInterface;

class LoyaltyProgram extends Subject
{
    private AccumulationStrategyInterface $strategy;
    /** @var PointsDecoratorInterface[] */
    private array $decorators = [];
    private int $points = 0;
    private string $tier;

    public function __construct(AccumulationStrategyInterface $strategy, string $tier = 'bronze')
    {
        $this->strategy = $strategy;
        $this->tier = $tier;
    }

    public function setStrategy(AccumulationStrategyInterface $strategy): void
    {
        $this->strategy = $strategy;
        $this->notifyAll('strategy_changed', ['strategy' => get_class($strategy)]);
    }

    public function addDecorator(PointsDecoratorInterface $d): void
    {
        $this->decorators[] = $d;
    }

    public function clearDecorators(): void
    {
        $this->decorators = [];
    }

    public function purchase(float $amount): int
    {
        $base = $this->strategy->accumulate($amount);
        $final = array_reduce($this->decorators, function($acc, $decor) {
            return $decor->apply($acc);
        }, $base);
        $this->points += $final;
        $this->notifyAll('points_accumulated', ['amount' => $amount, 'points' => $final, 'total' => $this->points]);
        return $final;
    }

    public function getPoints(): int
    {
        return $this->points;
    }

    public function changeTier(string $newTier): void
    {
        $old = $this->tier;
        $this->tier = $newTier;
        $this->notifyAll('tier_changed', ['from' => $old, 'to' => $newTier]);
    }

    public function expirePoints(int $points): void
    {
        $this->points = max(0, $this->points - $points);
        $this->notifyAll('points_expired', ['expired' => $points, 'total' => $this->points]);
    }
}

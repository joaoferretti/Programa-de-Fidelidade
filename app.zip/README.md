# Programa de Fidelidade — João Pedro Pires Ferretti

**Desenvolvido por:** João Pedro Pires Ferretti

Projeto em PHP implementando 3 padrões: Strategy, Decorator, Observer. Inclui Singleton para Config e uma Factory Method para criar estratégias.

## Como rodar
Requisitos: PHP >= 8.0, Composer.

Instalar dependências:
```
composer install
```

Rodar a CLI demo:
```
php app/cli.php
```

Rodar testes:
```
vendor/bin/phpunit --testdox
```
